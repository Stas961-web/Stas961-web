import React from 'react';
import { CardElement, useStripe, useElements } from '@stripe/react-stripe-js';

interface PaymentFormProps {
  amount: number;
  onSuccess: () => void;
  onCancel: () => void;
}

export const PaymentForm: React.FC<PaymentFormProps> = ({ amount, onSuccess, onCancel }) => {
  const stripe = useStripe();
  const elements = useElements();

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!stripe || !elements) return;

    const cardElement = elements.getElement(CardElement);
    if (!cardElement) return;

    const { error, paymentIntent } = await stripe.confirmCardPayment('{CLIENT_SECRET}', {
      payment_method: { card: cardElement },
    });

    if (error) {
      console.error(error);
    } else if (paymentIntent?.status === 'succeeded') {
      onSuccess();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Payment</h2>
      <p className="text-gray-600 mb-4">Amount: €{amount.toFixed(2)}</p>
      <CardElement className="border p-2 rounded-md" />
      <div className="flex justify-end mt-4 space-x-2">
        <button type="button" onClick={onCancel} className="bg-gray-300 px-4 py-2 rounded-md">
          Cancel
        </button>
        <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded-md">
          Pay
        </button>
      </div>
    </form>
  );
};