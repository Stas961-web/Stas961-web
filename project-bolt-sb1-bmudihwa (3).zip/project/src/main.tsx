import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Single instance of Google Maps loader
let mapsLoadPromise: Promise<void> | null = null;

window.loadGoogleMaps = () => {
  if (mapsLoadPromise) {
    return mapsLoadPromise;
  }

  mapsLoadPromise = new Promise<void>((resolve, reject) => {
    // Remove any existing Google Maps scripts
    document.querySelectorAll('script[src*="maps.googleapis.com"]').forEach(script => {
      script.parentNode?.removeChild(script);
    });

    const script = document.createElement('script');
    const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
    
    if (!apiKey) {
      reject(new Error('Google Maps API key is not defined'));
      return;
    }

    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places`;
    script.async = true;
    script.defer = true;

    script.addEventListener('load', () => {
      console.log('Google Maps loaded successfully');
      resolve();
    });

    script.addEventListener('error', (error) => {
      console.error('Failed to load Google Maps:', error);
      mapsLoadPromise = null; // Reset promise on error
      reject(new Error('Failed to load Google Maps'));
    });

    document.head.appendChild(script);
  });

  return mapsLoadPromise;
};

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);